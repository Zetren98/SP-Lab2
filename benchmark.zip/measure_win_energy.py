﻿import csv
import os
import sys
import time
import psutil

def read_csv_rows(csv_path):
    with open(csv_path, "rb") as f:
        raw = f.read()
    for enc in ("utf-8-sig", "utf-16", "cp1251", "latin-1"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    lines = [line for line in text.splitlines() if line.strip()]
    delim = ";" if lines[0].count(";") > lines[0].count(",") else ","
    return list(csv.reader(lines, delimiter=delim))

def find_power_column(headers):
    unit_tags = ("[w]", "[вт]")
    for group in (
        ("cpu package power", "package power", "cpu ppt", "мощность пакета", "потужність пакета", "повна споживана потужність цп"),
        ("cpu core power", "ia cores power", "total cpu power", "cpu power", "мощность цп", "потужність цп"),
        ("cpu", "цп", "package", "ppt", "core"),
    ):
        for i, h in enumerate(headers):
            hl = h.lower()
            if any(u in hl for u in unit_tags) and any(k in hl for k in group):
                return i, h
    raise RuntimeError("Датчик мощности ЦП не найден в заголовках CSV.")

def parse_col_values(rows, col_idx):
    vals = []
    for r in rows:
        if len(r) > col_idx and r[col_idx]:
            try:
                vals.append(float(r[col_idx].strip().replace(",", ".")))
            except ValueError:
                continue
    return vals

def main():
    csv_path = sys.argv[1]
    exe_cmd = sys.argv[2:]
    if os.path.exists(exe_cmd[0]):
        exe_cmd[0] = os.path.abspath(exe_cmd[0])

    rows_init = read_csv_rows(csv_path)
    power_col, col_name = find_power_column(rows_init[0])
    print(f"Using sensor column:  {col_name}")

    # 1. Калибровка фоновой мощности (минимум за 2 сек простоя, чтобы отсечь фоновые всплески)
    time.sleep(2.0)
    rows_before_run = read_csv_rows(csv_path)
    idle_vals = parse_col_values(rows_before_run[-10:], power_col)
    idle_watts = min(idle_vals) if idle_vals else 0.0
    start_row_idx = len(rows_before_run)

    # 2. Запуск исследуемого процесса
    sys_cpu_before = psutil.cpu_times()
    t0 = time.perf_counter()

    proc = psutil.Popen(exe_cmd)
    proc_cpu_time = 0.0
    while proc.poll() is None:
        try:
            ct = proc.cpu_times()
            proc_cpu_time = ct.user + ct.system
        except psutil.NoSuchProcess:
            break
        time.sleep(0.05)

    t_elapsed = time.perf_counter() - t0
    sys_cpu_after = psutil.cpu_times()

    # Пауза 0.6 сек, чтобы HWiNFO64 успел сбросить последние замеры из буфера в CSV
    time.sleep(0.6)
    rows_after_run = read_csv_rows(csv_path)
    active_vals = parse_col_values(rows_after_run[start_row_idx:], power_col)
    if not active_vals:
        active_vals = parse_col_values(rows_after_run[-3:], power_col)

    avg_sys_watts = sum(active_vals) / len(active_vals)
    e_system_j = avg_sys_watts * t_elapsed

    total_active_delta = (
        (sys_cpu_after.user - sys_cpu_before.user) +
        (sys_cpu_after.system - sys_cpu_before.system)
    )
    cpu_share = min(1.0, proc_cpu_time / max(1e-6, total_active_delta))

    e_dynamic_j = max(0.0, (avg_sys_watts - idle_watts) * t_elapsed)
    e_program_dyn_j = e_dynamic_j * cpu_share
    e_program_prop_j = e_system_j * cpu_share

    print(f"Command:              {' '.join(exe_cmd)}")
    print(f"Elapsed time:         {t_elapsed:.4f} s")
    print(f"Idle baseline power:  {idle_watts:.2f} W")
    print(f"Active system power:  {avg_sys_watts:.2f} W")
    print(f"System total energy:  {e_system_j:.3f} J")
    print(f"Process CPU share:    {cpu_share * 100:.1f} %")
    print(f"Program ONLY (dyn):   {e_program_dyn_j:.3f} J")
    print(f"Program ONLY (share): {e_program_prop_j:.3f} J")

if __name__ == "__main__":
    main()
