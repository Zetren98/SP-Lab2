﻿#include <iostream>
#include <vector>
#include <cstdlib>

float kernel_fma(const float* __restrict__ a, const float* __restrict__ b, size_t n) {
    float acc = 0.0f;
    for (size_t i = 0; i < n; ++i) {
        acc += a[i] * b[i] + 0.5f;
    }
    return acc;
}

float process_batch(const std::vector<float>& a, const std::vector<float>& b, int repeats) {
    float total = 0.0f;
    for (int r = 0; r < repeats; ++r) {
        total += kernel_fma(a.data(), b.data(), a.size());
    }
    return total;
}

int main(int argc, char** argv) {
    const size_t N = 1 << 22;
    const int REPEATS = (argc > 1) ? std::atoi(argv[1]) : 400;

    std::vector<float> a(N, 1.001f);
    std::vector<float> b(N, 0.999f);

    float result = process_batch(a, b, REPEATS);
    std::cout << "Result: " << result << "\n";
    return 0;
}
